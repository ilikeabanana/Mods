﻿using HarmonyLib;
using System.Collections.Generic;
using UnityEngine;

namespace BananaDifficulty.Patches
{
    // TODO Review this file and update to your own requirements, or remove it altogether if not required

    /// <summary>
    /// Sample Harmony Patch class. Suggestion is to use one file per patched class
    /// though you can include multiple patch classes in one file.
    /// Below is included as an example, and should be replaced by classes and methods
    /// for your mod.
    /// </summary>
    [HarmonyPatch(typeof(Gutterman))]
    internal class NoMoreBreakingShields
    {

        private static readonly Dictionary<Gutterman, int> gutterHitCount = new Dictionary<Gutterman, int>();

        [HarmonyPatch(nameof(Gutterman.ShieldBreak))]
        [HarmonyPrefix]
        public static bool Awake_Prefix(Gutterman __instance, bool flash = true)
        {
            if(!BananaDifficultyPlugin.CanUseIt(__instance.difficulty)) return true;


            if (gutterHitCount.ContainsKey(__instance))
            {
                if (gutterHitCount[__instance] >= 2)
                    return true;
                gutterHitCount[__instance]++;
            }
            else
            {
                Object.Instantiate(__instance.shieldBreakEffect, __instance.shield[0].transform.position, Quaternion.identity);
                gutterHitCount.Add(__instance, 1);
                return false;
            }
            return false;
        }
        /*
        [HarmonyPatch(nameof(Gutterman.Update))]
        [HarmonyPrefix]
        public static void NahDontWindUp(Gutterman __instance)
        {
            if(!BananaDifficultyPlugin.CanUseIt(__instance.difficulty)) return;


            __instance.windup = 1;
            __instance.trackingSpeedMultiplier = 100;
        }*/
    }
}